"""
F1 Telemetry Animation
------------------------
Animates two drivers' cars moving around the actual track shape, synced to
their fastest laps, colored by current speed. Saves as a GIF.

Run:  python animation.py
Output: lap_animation.gif  (open it in any image viewer / browser / drag into VS Code)
"""

import fastf1
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import os

CACHE_DIR = "cache"
os.makedirs(CACHE_DIR, exist_ok=True)
fastf1.Cache.enable_cache(CACHE_DIR)

YEAR, GP, SESSION_TYPE = 2024, "Monza", "Q"
DRIVER_1, DRIVER_2 = "VER", "NOR"
N_FRAMES = 150  # lower = faster to render, higher = smoother

session = fastf1.get_session(YEAR, GP, SESSION_TYPE)
session.load()

lap1 = session.laps.pick_driver(DRIVER_1).pick_fastest()
lap2 = session.laps.pick_driver(DRIVER_2).pick_fastest()
tel1 = lap1.get_telemetry()  # includes X, Y position + Speed, synced
tel2 = lap2.get_telemetry()

# resample both laps onto a common set of frame indices (0..1 of lap progress)
t1 = np.linspace(0, 1, len(tel1))
t2 = np.linspace(0, 1, len(tel2))
frame_t = np.linspace(0, 1, N_FRAMES)

x1 = np.interp(frame_t, t1, tel1["X"]); y1 = np.interp(frame_t, t1, tel1["Y"])
x2 = np.interp(frame_t, t2, tel2["X"]); y2 = np.interp(frame_t, t2, tel2["Y"])
spd1 = np.interp(frame_t, t1, tel1["Speed"]); spd2 = np.interp(frame_t, t2, tel2["Speed"])

fig, ax = plt.subplots(figsize=(8, 8))
ax.plot(tel1["X"], tel1["Y"], color="lightgray", linewidth=6, zorder=0)  # track outline
ax.set_aspect("equal")
ax.axis("off")
ax.set_title(f"{DRIVER_1} vs {DRIVER_2} — {GP} {YEAR} Fastest Lap")

dot1, = ax.plot([], [], "o", color="#1f77b4", markersize=12, label=DRIVER_1)
dot2, = ax.plot([], [], "o", color="#d62728", markersize=12, label=DRIVER_2)
txt = ax.text(0.02, 0.98, "", transform=ax.transAxes, va="top", fontsize=10)
ax.legend(loc="upper right")


def update(frame):
    dot1.set_data([x1[frame]], [y1[frame]])
    dot2.set_data([x2[frame]], [y2[frame]])
    txt.set_text(f"{DRIVER_1}: {spd1[frame]:.0f} km/h\n{DRIVER_2}: {spd2[frame]:.0f} km/h")
    return dot1, dot2, txt


ani = animation.FuncAnimation(fig, update, frames=N_FRAMES, interval=60, blit=True)
ani.save("lap_animation.gif", writer="pillow", fps=20)
print("Saved lap_animation.gif")
